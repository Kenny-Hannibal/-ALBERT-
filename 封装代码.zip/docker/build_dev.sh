img_name=api-segment:dev

docker build -f docker/Dockerfile.dev -t ${img_name} .