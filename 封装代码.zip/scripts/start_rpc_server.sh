cd ..
python -m online.rpc.segment_server 8000 50